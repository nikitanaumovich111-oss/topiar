<?php
// Скопируйте в topiar-config.php (ВЫШЕ папки сайта) или в config.php рядом с send-lead.php.
// Никогда не публикуйте реальный токен бота в репозитории.
return [
    'bot_token'      => 'НОВЫЙ_ТОКЕН_ОТ_BOTFATHER',
    'chat_id'        => 'ВАШ_CHAT_ID',
    'allowed_hosts'  => ['topiar.by', 'www.topiar.by'],
    'fallback_email' => 'info@topiar.by',
];
