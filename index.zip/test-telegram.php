<?php
// Диагностика отправки в Telegram. Запуск из папки сайта:  php test-telegram.php
// Токен в вывод не попадает.

$c = require __DIR__ . '/config.php';
$token = $c['bot_token'];
$chat  = $c['chat_id'];

echo "PHP " . PHP_VERSION . "\n";
foreach (['curl', 'openssl', 'mbstring'] as $ext) {
    echo str_pad($ext, 10) . (extension_loaded($ext) ? 'OK' : 'НЕТ') . "\n";
}
echo "php.ini:      " . (php_ini_loaded_file() ?: '(нет)') . "\n";
echo "curl.cainfo:  " . (ini_get('curl.cainfo') ?: '(не задан)') . "\n";
echo "openssl.cafile: " . (ini_get('openssl.cafile') ?: '(не задан)') . "\n\n";

function call(string $method, array $params, bool $verify): void {
    global $token;
    $ch = curl_init("https://api.telegram.org/bot{$token}/{$method}");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => $verify,
        CURLOPT_SSL_VERIFYHOST => $verify ? 2 : 0,
    ]);
    if ($verify && PHP_OS_FAMILY === 'Windows' && defined('CURLSSLOPT_NATIVE_CA')) {
        curl_setopt($ch, CURLOPT_SSL_OPTIONS, CURLSSLOPT_NATIVE_CA); // сертификаты из хранилища Windows
    }
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    $body = $body === false ? '' : str_replace($token, '<TOKEN>', $body);
    echo "[$method] проверка сертификата: " . ($verify ? 'да' : 'НЕТ (диагностика)') . "\n";
    echo "  HTTP:  $code\n";
    echo "  curl:  " . ($err !== '' ? $err : '(ошибок нет)') . "\n";
    echo "  ответ: " . mb_substr($body, 0, 400) . "\n\n";
}

call('getMe', [], true);
call('sendMessage', ['chat_id' => $chat, 'text' => 'Тест с сайта TOPIAR'], true);
// Если выше была ошибка SSL — этот вызов покажет, в сертификатах ли дело.
call('getMe', [], false);
