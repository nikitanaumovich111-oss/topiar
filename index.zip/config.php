<?php
return [
    'bot_token' => '8687025135:AAEa2HRc9B7OInrPW_GgN8ac0q3r5Pu2ZGk',
    'chat_id' => '931492862',
    // localhost и 127.0.0.1 нужны только для проверки на своём компьютере.
    // Перед выгрузкой на хостинг их можно убрать.
    'allowed_hosts' => ['topiar.by', 'www.topiar.by', 'localhost', '127.0.0.1'],
    'fallback_email' => 'info@topiar.by',
];
